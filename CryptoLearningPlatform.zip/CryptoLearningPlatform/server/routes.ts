import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { createSubscriptionPayment, createTestPayment, handlePaymentSuccess } from "./stripe";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  app.get("/api/courses", (_req, res) => {
    res.json(storage.getCourses());
  });

  app.get("/api/progress/:courseId", (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const progress = storage.getProgress(req.user.id, parseInt(req.params.courseId));
    res.json(progress);
  });

  app.post("/api/progress/:courseId", (req, res) => {
    if (!req.user) return res.sendStatus(401);
    const schema = z.object({ watchedSeconds: z.number() });
    const { watchedSeconds } = schema.parse(req.body);

    storage.updateProgress(req.user.id, parseInt(req.params.courseId), watchedSeconds);
    res.sendStatus(200);
  });

  app.post("/api/courses/:courseId/complete", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const courseId = parseInt(req.params.courseId);
    const progress = storage.getProgress(req.user.id, courseId);

    if (!progress?.completed) {
      await storage.completeCourse(req.user.id, courseId);
      res.sendStatus(200);
    } else {
      res.sendStatus(400);
    }
  });

  // Payment routes
  app.post("/api/payments/subscription", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    const schema = z.object({ plan: z.enum(["economical", "premium"]) });
    const { plan } = schema.parse(req.body);

    try {
      const paymentIntent = await createSubscriptionPayment(req.user.id, plan);
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Payment creation failed:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.post("/api/payments/test", async (req, res) => {
    if (!req.user) return res.sendStatus(401);

    try {
      const paymentIntent = await createTestPayment(req.user.id);
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Payment creation failed:", error);
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.post("/api/payments/webhook", async (req, res) => {
    const paymentIntentId = req.body.data?.object?.id;
    if (!paymentIntentId) {
      return res.sendStatus(400);
    }

    try {
      await handlePaymentSuccess(paymentIntentId);
      res.sendStatus(200);
    } catch (error) {
      console.error("Payment webhook failed:", error);
      res.status(500).json({ message: "Failed to process payment webhook" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}