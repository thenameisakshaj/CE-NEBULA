import Stripe from "stripe";
import { storage } from "./storage";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing STRIPE_SECRET_KEY");
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
});

export const SUBSCRIPTION_PRICES = {
  economical: {
    amount: 14900, // ₹149 in paise
    currency: "inr",
  },
  premium: {
    amount: 49900, // ₹499 in paise
    currency: "inr",
  },
};

export const TEST_PRICE = {
  amount: 14900, // ₹149 in paise
  currency: "inr",
  eraCoins: 5,
};

export async function createSubscriptionPayment(userId: number, plan: "economical" | "premium") {
  const price = SUBSCRIPTION_PRICES[plan];
  
  const paymentIntent = await stripe.paymentIntents.create({
    amount: price.amount,
    currency: price.currency,
    metadata: {
      userId: userId.toString(),
      type: "subscription",
      plan,
    },
  });

  return paymentIntent;
}

export async function createTestPayment(userId: number) {
  const paymentIntent = await stripe.paymentIntents.create({
    amount: TEST_PRICE.amount,
    currency: TEST_PRICE.currency,
    metadata: {
      userId: userId.toString(),
      type: "test",
      eraCoins: TEST_PRICE.eraCoins.toString(),
    },
  });

  return paymentIntent;
}

export async function handlePaymentSuccess(paymentIntentId: string) {
  const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
  const { userId, type, plan, eraCoins } = paymentIntent.metadata;

  const user = await storage.getUser(parseInt(userId));
  if (!user) return;

  if (type === "subscription") {
    user.subscription = plan;
  } else if (type === "test" && eraCoins) {
    user.eraCoins -= parseInt(eraCoins);
  }

  await storage.updateUser(user);
}
