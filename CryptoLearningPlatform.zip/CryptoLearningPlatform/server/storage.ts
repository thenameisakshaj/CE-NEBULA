import { IStorage } from "./storage";
import createMemoryStore from "memorystore";
import session from "express-session";
import { Course, Progress, User, InsertUser } from "@shared/schema";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private courses: Map<number, Course>;
  private progress: Map<string, Progress>;
  sessionStore: session.SessionStore;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.courses = new Map();
    this.progress = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });

    // Add mock courses
    this.courses.set(1, {
      id: 1,
      title: "Introduction to Blockchain",
      description: "Learn the fundamentals of blockchain technology",
      videoUrl: "https://example.com/video1.mp4",
      thumbnail: "https://via.placeholder.com/400x300",
    });
    this.courses.set(2, {
      id: 2,
      title: "Web3 Development",
      description: "Build decentralized applications",
      videoUrl: "https://example.com/video2.mp4",
      thumbnail: "https://via.placeholder.com/400x300",
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const normalizedUsername = username.toLowerCase();
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === normalizedUsername
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = {
      ...insertUser,
      id,
      eraCoins: 0,
      subscription: "economical",
      username: insertUser.username.toLowerCase(), // Store username in lowercase
    };
    this.users.set(id, user);
    return user;
  }

  getCourses(): Course[] {
    return Array.from(this.courses.values());
  }

  getProgress(userId: number, courseId: number): Progress | undefined {
    return this.progress.get(`${userId}-${courseId}`);
  }

  updateProgress(userId: number, courseId: number, watchedSeconds: number) {
    const key = `${userId}-${courseId}`;
    const existing = this.progress.get(key);
    
    this.progress.set(key, {
      id: existing?.id ?? this.currentId++,
      userId,
      courseId,
      completed: existing?.completed ?? false,
      watchedSeconds,
    });
  }

  async completeCourse(userId: number, courseId: number) {
    const key = `${userId}-${courseId}`;
    const existing = this.progress.get(key);
    
    this.progress.set(key, {
      id: existing?.id ?? this.currentId++,
      userId,
      courseId,
      completed: true,
      watchedSeconds: existing?.watchedSeconds ?? 0,
    });
  
    const user = await this.getUser(userId);
    if (user) {
      user.eraCoins += 8;
      this.users.set(userId, user);
    }
  }

  async updateUser(user: User): Promise<User> {
    this.users.set(user.id, user);
    return user;
  }
}

export const storage = new MemStorage();