import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <header className="bg-primary/5 py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6">
            Welcome to{" "}
            <span className="bg-gradient-to-r from-primary to-primary/70 text-transparent bg-clip-text">
              CryptoERA
            </span>
          </h1>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Learn from expert-curated courses and earn Era Coins while mastering new skills. Start your learning journey today!
          </p>
          <Link href="/auth">
            <Button size="lg" className="font-semibold">
              Get Started
            </Button>
          </Link>
        </div>
      </header>

      <main className="max-w-6xl mx-auto py-20 px-4">
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <motion.div 
            className="p-6 rounded-lg bg-card cursor-pointer"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
              background: "linear-gradient(145deg, hsl(var(--card)) 0%, hsl(var(--card)) 100%)"
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <h3 className="text-xl font-semibold mb-4">Learn</h3>
            <p>Access premium video courses from industry experts</p>
          </motion.div>
          <motion.div 
            className="p-6 rounded-lg bg-card cursor-pointer"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
              background: "linear-gradient(145deg, hsl(var(--card)) 0%, hsl(var(--card)) 100%)"
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <h3 className="text-xl font-semibold mb-4">Earn</h3>
            <p>Get rewarded with Era Coins for completing courses</p>
          </motion.div>
          <motion.div 
            className="p-6 rounded-lg bg-card cursor-pointer"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
              background: "linear-gradient(145deg, hsl(var(--card)) 0%, hsl(var(--card)) 100%)"
            }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <h3 className="text-xl font-semibold mb-4">Grow</h3>
            <p>Take industry tests and get certified</p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
