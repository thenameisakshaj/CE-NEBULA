import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Course } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import VideoPlayer from "./video-player";
import { useState } from "react";
import CourseDetailsDialog from "./course-details-dialog";
import { Eye } from "lucide-react";

interface CourseCardProps {
  course: Course;
}

export default function CourseCard({ course }: CourseCardProps) {
  const [showVideo, setShowVideo] = useState(false);
  const [showDetails, setShowDetails] = useState(false);

  const { data: progress } = useQuery({
    queryKey: ["/api/progress", course.id],
  });

  const progressPercent = progress ? (progress.watchedSeconds / 300) * 100 : 0;

  return (
    <Card>
      {showVideo ? (
        <VideoPlayer
          courseId={course.id}
          videoUrl={course.videoUrl}
          onClose={() => setShowVideo(false)}
        />
      ) : (
        <>
          <CardHeader>
            <CardTitle>{course.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <img
              src={course.thumbnail}
              alt={course.title}
              className="w-full h-48 object-cover rounded-md mb-4"
            />
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {course.description}
            </p>
            <Progress value={progressPercent} className="h-2" />
          </CardContent>
          <CardFooter>
            <Button
              className="w-full"
              onClick={() => setShowDetails(true)}
              variant={progressPercent > 0 ? "default" : "secondary"}
            >
              <Eye className="w-4 h-4 mr-2" />
              {progressPercent > 0 ? "Continue Learning" : "View Details"}
            </Button>
          </CardFooter>
        </>
      )}

      <CourseDetailsDialog
        course={course}
        open={showDetails}
        onOpenChange={setShowDetails}
        onStartCourse={() => {
          setShowDetails(false);
          setShowVideo(true);
        }}
      />
    </Card>
  );
}