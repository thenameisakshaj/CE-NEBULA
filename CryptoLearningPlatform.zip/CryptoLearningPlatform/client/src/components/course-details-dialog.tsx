import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Course } from "@shared/schema";
import { Play } from "lucide-react";

interface CourseDetailsDialogProps {
  course: Course;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStartCourse: () => void;
}

export default function CourseDetailsDialog({
  course,
  open,
  onOpenChange,
  onStartCourse,
}: CourseDetailsDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle>{course.title}</DialogTitle>
          <DialogDescription>
            Earn 8 Era Coins upon completion
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <img
            src={course.thumbnail}
            alt={course.title}
            className="w-full aspect-video object-cover rounded-lg"
          />
          <div className="space-y-2">
            <h3 className="font-semibold">About this course</h3>
            <p className="text-sm text-muted-foreground">
              {course.description}
            </p>
          </div>
        </div>
        <div className="flex justify-end">
          <Button onClick={onStartCourse} className="w-full sm:w-auto">
            <Play className="w-4 h-4 mr-2" />
            Start Learning
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}