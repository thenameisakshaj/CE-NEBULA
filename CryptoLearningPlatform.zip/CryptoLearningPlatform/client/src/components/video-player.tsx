import { useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface VideoPlayerProps {
  courseId: number;
  videoUrl: string;
  onClose: () => void;
}

export default function VideoPlayer({ courseId, videoUrl, onClose }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = async () => {
      try {
        await apiRequest("POST", `/api/progress/${courseId}`, {
          watchedSeconds: Math.floor(video.currentTime),
        });
      } catch (error) {
        console.error("Failed to update progress:", error);
      }
    };

    const handleEnded = async () => {
      try {
        await apiRequest("POST", `/api/courses/${courseId}/complete`);
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        toast({
          title: "Course Completed!",
          description: "You've earned 8 Era Coins!",
        });
      } catch (error) {
        console.error("Failed to complete course:", error);
      }
    };

    video.addEventListener("timeupdate", handleTimeUpdate);
    video.addEventListener("ended", handleEnded);

    return () => {
      video.removeEventListener("timeupdate", handleTimeUpdate);
      video.removeEventListener("ended", handleEnded);
    };
  }, [courseId, toast]);

  return (
    <Card className="relative">
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-2 z-10"
        onClick={onClose}
      >
        <X className="h-4 w-4" />
      </Button>
      <video
        ref={videoRef}
        src={videoUrl}
        controls
        className="w-full aspect-video"
      />
    </Card>
  );
}
